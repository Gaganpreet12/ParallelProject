package com.cg.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bean.BankTransaction;
import com.cg.exceptions.*;
import com.cg.service.BankService;
import com.cg.service.BankServiceInterface;

public class BankMainUi {
	static Scanner scan = new Scanner(System.in);
	static BankTransaction transObj = new BankTransaction();
	static BankTransaction transObj1 = new BankTransaction();

	public static void main(String[] args) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		//declaring variables
		
		int withdrawAmount, depositAmount = 0, transferAmount = 0;
		int pinNum = 0;
		long accNum, accNum1;
		int amount = 0;
		boolean result = false;
		String flag = "yes";
		int balance = 0;

		//creating service class object
		BankServiceInterface serviceObj = new BankService();

		// To ask choice from users and perform operations
		while (flag.equalsIgnoreCase("yes")) {
			switch (menu()) {

			// to create account

			case 1:

				System.out.println("Enter your name:");
				String userName = scan.nextLine();
				userName += scan.nextLine();

				String regexUserName = "[A-Z][a-z\\s]+$";
				while (!userName.matches(regexUserName)) {

					System.out.println("Invalid Name format");
					System.out.println("Enter name");
					userName = scan.next();
				}

				System.out.println("Enter address: ");
				String address = scan.next();
				address += scan.nextLine();

				while (!address.matches(regexUserName)) {
					System.out.println("Invalid Address format");
					System.out.println("Enter address ");
					address = scan.nextLine();

				}

				System.out.println("Enter your phone number:");
				String phoneNum = scan.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phoneNum.matches(phone_format)) {
					while (phoneNum.length() < 10 || phoneNum.length() > 10) {

						System.out.println("Phone number should be of 10 digits");
						System.out.println("Enter phone number:");
						phoneNum = scan.next();
					}
					System.out.println("Phone number should start from 6");
					System.out.println("Enter phone number:");
					phoneNum = scan.next();
				}

				accNum = Long.parseLong(phoneNum) - 10000;

				System.out.println("Enter your Pin:");
				pinNum = scan.nextInt();

				while (String.valueOf(pinNum).length() < 4 || String.valueOf(pinNum).length() > 4) {

					System.out.println("Pin number should be of 4 digits.");
					System.out.println("Enter your Pin:");
					pinNum = scan.nextInt();
				}

				System.out.println("Enter Balance:");
				int balance1 = scan.nextInt();

				while (balance1 < 1000) {
					System.out.println("Minimum Balance should be 1000.");
					System.out.println("Enter Balance:");
					balance1 = scan.nextInt();

				}
				try {
					result = serviceObj.createAccount(userName, address, accNum, phoneNum, pinNum, balance1);
				} catch (AccountAlreadyExistsException exception) {

					System.out.println(exception);
					break;
				}

				if (result == true) {
					System.out.println("Account Created Successfully !!!");
					System.out.println("Account Number : " + accNum);

					int transactionId = ((int) Math.random() * 1000 + 1000);
					transObj.setAccNum(accNum);
					transObj.setType("Create");
					transObj.setAmount(balance1);
					transObj.setTransactionId(transactionId);

					serviceObj.setTransactions(transObj);

				} else {

					System.out.println("Account cannot be created.");
				}

				break;

			// to show balance
			case 2:

				System.out.println("Enter account number");
				accNum = scan.nextLong();

				try {
					balance = serviceObj.showBalance(accNum);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance :" + balance);

				break;

			// to deposit amount

			case 3:

				System.out.println("Enter the account number:");
				accNum = scan.nextLong();

				System.out.println("Enter the amount to be deposited:");
				depositAmount = scan.nextInt();

				try {
					amount = serviceObj.deposit(accNum, depositAmount);

					balance = serviceObj.showBalance(accNum);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited : " + depositAmount);
				System.out.println("Updated Balance : " + balance);

				int trans_id = ((int) Math.random() * 1000 + 1000);
				transObj.setAccNum(accNum);
				transObj.setType("Deposit");
				transObj.setAmount(depositAmount);
				transObj.setTransactionId(trans_id);
				serviceObj.setTransactions(transObj);

				break;

			// to withdraw amount

			case 4:

				System.out.println("Enter account number:");
				accNum = scan.nextLong();

				System.out.println("Enter the amount to withdraw:");
				withdrawAmount = scan.nextInt();

				try {
					amount = serviceObj.withdraw(accNum, withdrawAmount);
					result = serviceObj.validateBalance(accNum, withdrawAmount);
					balance = serviceObj.showBalance(accNum);

				} catch (AccountNotFoundException exception) {

					System.out.println(exception);
					break;

				} catch (LowBalanceException exception) {

					System.out.println(exception);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdrawAmount);
				System.out.println("Updated Balance : " + balance);

				int transId = ((int) Math.random() * 1000 + 1000);
				transObj.setAccNum(accNum);
				transObj.setType("Withdraw");
				transObj.setAmount(withdrawAmount);
				transObj.setTransactionId(transId);
				serviceObj.setTransactions(transObj);

				break;

			// to transfer funds

			case 5:

				int sendBalance = 0;
				int receivedBalance = 0;

				System.out.println("Enter account number:");
				accNum = scan.nextLong();

				System.out.println("Enter account to which you want to transfer funds:");
				accNum1 = scan.nextLong();

				System.out.println("Enter the amount to transfer:");
				transferAmount = scan.nextInt();

				try {
					result = serviceObj.validateBalance(accNum, transferAmount);
					result = serviceObj.transferfund(accNum, accNum1, transferAmount);

					sendBalance = serviceObj.showBalance(accNum);
					receivedBalance = serviceObj.showBalance(accNum1);

				} catch (AccountNotFoundException exception) {

					System.out.println(exception);
					break;
				} catch (LowBalanceException exception) {
					System.out.println(exception);
					break;
				}

				System.out.println("Amount transferred Successfully!!");
				System.out.println("Updated balance for Account " + accNum + " : " + sendBalance);
				System.out.println("Updated balance for Account " + accNum1 + " : " + receivedBalance);

				int transactions = ((int) Math.random() * 1000 + 1000);
				transObj.setAccNum(accNum);
				transObj.setType("Transfer");
				transObj.setAmount(transferAmount);
				transObj.setTransactionId(transactions);
				serviceObj.setTransactions(transObj);

				int transId1 = ((int) Math.random() * 1000 + 1000);
				transObj1.setAccNum(accNum1);
				transObj1.setType("Transfer");
				transObj1.setAmount(transferAmount);
				transObj1.setTransactionId(transId1);
				serviceObj.setTransactions(transObj1);

				break;

			// to show transactions
			case 6:

				System.out.println("Enter account number:");
				accNum = scan.nextLong();
				transObj = serviceObj.getTransactions(accNum);
				if (transObj == null) {
					throw new AccountNotFoundException();
				} 
				else {
					System.out.println("--------Transaction Details----------");
					System.out.println("Transaction type : " + transObj.getType());
					System.out.println("Transaction Id : " + transObj.getTransactionId());
					System.out.println("Transaction Account : " + transObj.getAccNum());
					System.out.println("Transaction Amount : " + transObj.getAmount());
				}

			// to exit
			case 7:
				System.out.println("          Thank You");
				System.exit(0);
				flag = "no";
				break;
			default:
				System.out.println("Please Enter choice between 1 - 7 ");
				menu();

			}
		}

	}

	// to display menu
	public static int menu() {

		System.out.println("\n------------Welcome to HDFC Bank----------");
		System.out.println("Enter : 1 to Create Account");
		System.out.println("Enter : 2 to Show Balance");
		System.out.println("Enter : 3 to Deposit");
		System.out.println("Enter : 4 to Withdraw");
		System.out.println("Enter : 5 to Transfer Funds");
		System.out.println("Enter : 6 to Print Transcations");
		System.out.println("Enter : 7 to Exit\n");
		System.out.println("-------------------------------------------\n");

		System.out.println("Enter your Choice:");
		int choice = scan.nextInt();
		String str = Integer.toString(choice);
		String pattern = ("[0-7]{1}");
		while (!str.matches(pattern)) {
			System.out.println("Invalid Choice!!");
			System.out.println("Enter your Choice:");
			choice = scan.nextInt();
		}

		return choice;
	}

}
