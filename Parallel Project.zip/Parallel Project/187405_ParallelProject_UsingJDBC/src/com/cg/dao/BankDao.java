package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.BankBean;
import com.cg.bean.BankTransaction;

public class BankDao implements BankDaoInterface {
	
	
	BankBean bankObj = new BankBean();
	Connection connect = null;
	PreparedStatement prepStmt = null;
	ResultSet resSet = null;
	
	@Override
	public void InsertData(long accNum, BankBean beanObj) throws ClassNotFoundException, SQLException {

		connect = BankDatabase.getConnection();
		prepStmt = connect.prepareStatement("Insert into bank values (?,?,?,?,?,?)");

		prepStmt.setString(1, beanObj.getName());
		prepStmt.setLong(2, beanObj.getAccNum());
		prepStmt.setLong(3, beanObj.getPinNum());
		prepStmt.setString(4, beanObj.getAddress());
		prepStmt.setString(5, beanObj.getName());
		prepStmt.setInt(6, beanObj.getBalance());

		int rest = prepStmt.executeUpdate();

		if (rest == 0) {
			System.out.println("Not inserted");
		} else {
			System.out.println("Value inserted");
		}
	}

	@Override
	public boolean checkAccount(long accNum) throws ClassNotFoundException, SQLException {

		boolean result = false;

		String query = "Select * from bank where accountno = ?";
		connect = BankDatabase.getConnection();
		prepStmt = connect.prepareStatement(query);
		prepStmt.setLong(1, accNum);
		resSet = prepStmt.executeQuery();

		if (resSet.next()) {
			result = false;
		} else {
			result = true;
		}
		return result;
	}


	@Override
	public void updateData(BankBean beanObj) throws ClassNotFoundException, SQLException {

		connect = BankDatabase.getConnection();
		prepStmt = connect.prepareStatement("Update bank set balance = ? where accountno = ?");
		prepStmt.setInt(1, beanObj.getBalance());
		prepStmt.setLong(2, beanObj.getAccNum());

		int rest = prepStmt.executeUpdate();

		if (rest == 0) {
			System.out.println("Cannot update");
		} else {
			System.out.println("Updated");
		}
	}

	@Override
	public BankBean getAccountDetails(long accNum) throws ClassNotFoundException, SQLException {
		//boolean result = false;

		String query = "Select * from bank where accountno = ?";
		connect = BankDatabase.getConnection();
		prepStmt = connect.prepareStatement(query);
		prepStmt.setLong(1, accNum);
		resSet = prepStmt.executeQuery();

		if (resSet.next()) {
			bankObj.setName(resSet.getString(1));
			bankObj.setAccNum(resSet.getLong(2));
			bankObj.setPinNum(resSet.getInt(3));
			bankObj.setAddress(resSet.getString(4));
			bankObj.setPhoneNum(resSet.getString(5));
			bankObj.setBalance(resSet.getInt(6));
		} else {
			bankObj = null;
		}
		return bankObj;
	}

	@Override
	public void setTransactions(BankTransaction transObj) throws ClassNotFoundException, SQLException {

		String query = "Insert into transactions values (?,?,?,?)";
		connect = BankDatabase.getConnection();
		prepStmt = connect.prepareStatement(query);
		prepStmt.setString(1, transObj.getType());
		prepStmt.setLong(2, transObj.getAccNum());
		prepStmt.setInt(3, transObj.getAmount());
		prepStmt.setInt(4, transObj.getTransactionId());

		int result = prepStmt.executeUpdate();

		if (result == 0) {
			System.out.println("Cannot insert");
		} else {
			System.out.println("Updated ");
		}

	}

	@Override
	public BankTransaction getTransactions(long accNum) throws ClassNotFoundException, SQLException {

		BankTransaction transObj = new BankTransaction();
		String query = "Select * from transactions where accountno = ?";
		connect = BankDatabase.getConnection();
		prepStmt = connect.prepareStatement(query);
		prepStmt.setLong(1, accNum);

		resSet = prepStmt.executeQuery();

		if (resSet.next()) {
			transObj.setType(resSet.getString(1));
			transObj.setAccNum(resSet.getLong(2));
			transObj.setAmount(resSet.getInt(3));
			transObj.setTransactionId(resSet.getInt(4));
		}
		return transObj;
	}

}
