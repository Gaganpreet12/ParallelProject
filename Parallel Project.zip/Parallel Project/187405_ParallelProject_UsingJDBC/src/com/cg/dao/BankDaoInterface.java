package com.cg.dao;

import java.sql.SQLException;

import com.cg.bean.BankBean;
import com.cg.bean.BankTransaction;

public interface BankDaoInterface {



	public void InsertData(long accNum, BankBean beanObj) throws ClassNotFoundException, SQLException;
	
	public void updateData(BankBean beanObj) throws ClassNotFoundException, SQLException;

	public boolean checkAccount(long accNum) throws ClassNotFoundException, SQLException;

	public BankBean getAccountDetails(long accNum) throws ClassNotFoundException, SQLException;

	public void setTransactions(BankTransaction transObj) throws ClassNotFoundException, SQLException;

	public BankTransaction getTransactions(long accNum) throws ClassNotFoundException, SQLException;

}
