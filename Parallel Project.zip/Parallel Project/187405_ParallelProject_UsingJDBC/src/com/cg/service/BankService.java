package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.BankBean;
import com.cg.bean.BankTransaction;
import com.cg.dao.BankDao;
import com.cg.dao.BankDaoInterface;
import com.cg.exceptions.*;

public class BankService implements BankServiceInterface {

	BankDaoInterface daoObj = (BankDaoInterface) new BankDao();
	BankBean bankObj = new BankBean();
	BankBean bankObj1 = new BankBean();

	boolean result;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String address, long accNum, String phoneNum, int pinNum, int balance)
			throws AccountAlreadyExistsException, ClassNotFoundException, SQLException {

		BankBean beanObj = new BankBean();
		boolean flag = false;
		flag = daoObj.checkAccount(accNum);

		if (flag) {
			beanObj.setAccNum(accNum);
			beanObj.setAddress(address);
			beanObj.setBalance(balance);
			beanObj.setName(name);
			beanObj.setPhoneNum(phoneNum);
			beanObj.setPinNum(pinNum);
			beanObj.setTransaction("Account Created with Balance  : " + balance + "\n");

			daoObj.InsertData(accNum, beanObj);

			flag = true;
		}

		else

		{
			flag = false;
			throw new AccountAlreadyExistsException();
		}
		return flag;

	}

	// to show balance

	public int showBalance(long accNum) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		try {
			result = daoObj.checkAccount(accNum);
		}

		catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		int balance = 0;

		if (result) {
			throw new AccountNotFoundException();
		} else {
			bankObj = daoObj.getAccountDetails(accNum);
			balance = bankObj.getBalance();
		}

		return balance;
	}

	// to deposit amount

	public int deposit(long accNum, int depositAmount)
			throws AccountNotFoundException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			result = daoObj.checkAccount(accNum);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		if (result) {
			throw new AccountNotFoundException();
		} else {
			bankObj = daoObj.getAccountDetails(accNum);
		}
		if (bankObj == null) {
			throw new AccountNotFoundException();
		} else {

			balance = bankObj.setBalance(bankObj.getBalance() + depositAmount);
			String str = bankObj.getTransaction() + "Amount deposited :Rs " + depositAmount + "\n";
			bankObj.setTransaction(str);
			daoObj.updateData(bankObj);
		}

		return balance;
	}

	// to withdraw amount

	public int withdraw(long accNum, int withdrawAmount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			result = daoObj.checkAccount(accNum);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		if (result) {
			throw new AccountNotFoundException();
		} else {
			bankObj = daoObj.getAccountDetails(accNum);
			if (bankObj == null) {
				throw new AccountNotFoundException();
			}
			if (bankObj.getBalance() > withdrawAmount) {
				balance = bankObj.setBalance(bankObj.getBalance() - withdrawAmount);
				String s = bankObj.getTransaction() + "Amount withdrawn :Rs " + withdrawAmount + "\n";
				bankObj.setTransaction(s);
			} else {
				throw new LowBalanceException();
			}
			// dao.InsertData(accNo, bank);
			daoObj.updateData(bankObj);
		}

		return balance;
	}

	// to transfer funds

	public boolean transferfund(long accNum, long accNum1, int transferAmount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		result = daoObj.checkAccount(accNum);
		if (result) {
			throw new AccountNotFoundException();
		} else {
			bankObj = daoObj.getAccountDetails(accNum);
			int balance = bankObj.getBalance();
			result = validateBalance(accNum, transferAmount);
			if (result) {
				result = daoObj.checkAccount(accNum1);
				if (result) {
					throw new AccountNotFoundException();
				} else {
					bankObj1 = daoObj.getAccountDetails(accNum1);
					int balance1 = bankObj1.getBalance();
					bankObj.setBalance(balance - transferAmount);
					bankObj1.setBalance(balance1 + transferAmount);
					daoObj.updateData(bankObj);
					daoObj.updateData(bankObj1);
				}
			} else {
				throw new LowBalanceException();

			}
		}
		return true;
	}

	// to validate Balance

	public boolean validateBalance(long accNum, int amount)
			throws LowBalanceException, AccountNotFoundException, ClassNotFoundException, SQLException

	{

		result = daoObj.checkAccount(accNum);
		if (result) {
			throw new AccountNotFoundException();
		} else {
			bankObj = daoObj.getAccountDetails(accNum);
			int balance = bankObj.getBalance();
			if (balance < amount) {
				throw new LowBalanceException();
			} else {
				return true;
			}
		}
	}

	// to set transactions

	public String setTrans(long accNum) throws AccountNotFoundException {

		try {
			result = daoObj.checkAccount(accNum);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		String string;

		if (bankObj == null) {
			throw new AccountNotFoundException();
		} else {
			string = bankObj.getTransaction();
		}
		return string;
	}

	@Override
	public void setTransactions(BankTransaction transObj) throws ClassNotFoundException, SQLException {

		daoObj.setTransactions(transObj);
	}

	@Override
	public BankTransaction getTransactions(long accNum) throws ClassNotFoundException, SQLException {
		BankTransaction transObj = new BankTransaction();
		transObj = daoObj.getTransactions(accNum);
		return transObj;
	}
}
