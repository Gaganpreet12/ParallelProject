package com.cg.bean;

public class BankBean {
	
	String transaction = new String();
	private int pinNum;
	private int balance;
	private String phoneNum;
	private String name;
	private long accNum;
	private String address;

	public BankBean() {
		// TODO Auto-generated constructor stub
	}

	public BankBean(String name, int accNum, int pinNum, String dob2, String address, String phoneNum, int balance) {
		super();
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String string) {
		transaction = string;
	}
	
	public int getPinNum() {
		return pinNum;
	}

	public void setPinNum(int pinNum) {
		this.pinNum = pinNum;
	}


	public int getBalance() {
		return balance;
	}

	public int setBalance(int balance) {
		return this.balance = balance;
	}

	public String getPhoneNum() {
		return phoneNum;
	}
	
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccNum() {
		return accNum;
	}

	public long setAccNum(long accNum) {
		return this.accNum = accNum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Account Details Name =" + name + "\n Acc Number =" + accNum + "\n Pin =" + pinNum + "\n Address =" + address
				+ "\n Phone Number =" + phoneNum + "\nBalance =" + balance;
	}


}