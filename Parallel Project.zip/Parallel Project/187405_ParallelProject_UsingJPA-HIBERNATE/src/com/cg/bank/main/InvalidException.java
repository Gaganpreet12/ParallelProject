package com.cg.bank.main;

public class  InvalidException extends Exception {
public InvalidException(String message){
	System.out.println(message);
}
}
