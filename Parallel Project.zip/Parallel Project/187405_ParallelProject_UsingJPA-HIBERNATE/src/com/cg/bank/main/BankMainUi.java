package com.cg.bank.main;

import java.util.Scanner;

import com.cg.bank.entity.BankDetails;
import com.cg.bank.entity.TransactionDetails;
import com.cg.bank.service.BankService;

public class BankMainUi {
	public static void Menu() {
		System.out.println("\n\n---------------Welcome to HDFC Bank--------------------");
		System.out.println("Enter :");
		System.out.println(
				"1. CreateAccount\n2. Show Balance\n3. Deposit\n4. WithDraw\n5. Fund Transfer\n6. Print Transaction\n7. Exit");
		System.out.println("--------------------------------------------------------\n");
	}

	public static void main(String[] args) throws InvalidException {
		do {
			Menu();

			Scanner scan = new Scanner(System.in);
			BankService serviceObj = new BankService();
			BankDetails bankObj = new BankDetails();
			TransactionDetails transObj = new TransactionDetails();
			TransactionDetails transObj1 = new TransactionDetails();
			System.out.println("Enter your choice:");
			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("Creating an Account:\n");
				System.out.println("Enter your Name:");
				String name = scan.next();
				if (name == null || name.length() > 12) {
					throw new InvalidException("Enter valid Name: ");
				}
				System.out.println("Enter Mobile Number:");
				String mobileNum = scan.next();
				if (mobileNum.length() != 10) {
					throw new InvalidException("Enter valid Mobile Number:");
				}

				bankObj.setAccId();
				bankObj.setAccountantName(name);
				bankObj.setMobileno(mobileNum);
				bankObj.setAccBalance(1000);

				serviceObj.CreateAccount(bankObj); // Service class calling

				System.out.println("Account created Successfully!!");
				int accId = bankObj.getAccId();
				serviceObj.getAccountById(accId);
				System.out.println("Account Id is :" + bankObj.getAccId());

				System.out.println("-------------------------------------------------------------");
				break;
				
				//show balance
			case 2:
				System.out.println("Enter your account Id:");
				int accid = scan.nextInt();
				if (accid == 0) {
					throw new InvalidException("Enter valid Account Id");
				}
				bankObj = serviceObj.getAccountById(accid);
				System.out.println("Accountant Name: " + bankObj.getAccountantName());
				System.out.println("Your Balance is: " + bankObj.getAccBalance());
				System.out.println("\n-------------------------------------------------------------");
				break;

			case 3:
				System.out.println("-------Deposit--------");
				System.out.println("Enter your Account Id:\n");
				int depId = scan.nextInt();
				if (depId == 0) {
					throw new InvalidException("Enter valid Account Id.\n");
				}
				bankObj = serviceObj.getAccountById(depId);
				System.out.println("Accountant Name: " + bankObj.getAccountantName());
				System.out.println("Your Account Balance is: " + bankObj.getAccBalance());
				int initBalance = bankObj.getAccBalance();
				System.out.println("Enter the amount you want to Deposit:\n");
				int depAmt = scan.nextInt();
				int finalBalance = initBalance + depAmt;
				bankObj.setAccBalance(finalBalance);
				serviceObj.Deposit(bankObj);

				// Updating In Transaction Table

				transObj.setTransactionType("Deposit");
				transObj.setAccId(depId);
				transObj.setAmount(depAmt);
				serviceObj.addTransaction(transObj);
				bankObj.setTransaction(transObj);

				bankObj = serviceObj.getAccountById(depId);
				System.out.println("Hello!! Welcome " + bankObj.getAccountantName());
				System.out.println(
						"Your Account Balance after Depositing Rs" + depAmt + " is " + bankObj.getAccBalance());
				System.out.println("\n-------------------------------------------------------------\n");
				break;
			case 4:
				System.out.println("--------Withdraw--------");
				System.out.println("Enter your account Id:");
				int withId = scan.nextInt();
				if (withId == 0) {
					throw new InvalidException("Enter valid Account Id.");
				}
				bankObj = serviceObj.getAccountById(withId);
				System.out.println("Hello!! Welcome " + bankObj.getAccountantName());
				System.out.println(" Your Account Balance is: " + bankObj.getAccBalance());
				int intbal = bankObj.getAccBalance(); // initial balance
				System.out.println("-------------------------------------------");
				System.out.println("Enter the Amount you want to Withdraw: ");
				int withdrawAmt = scan.nextInt();
				int finalBal = intbal - withdrawAmt;
				bankObj.setAccBalance(finalBal);
				serviceObj.Withdraw(bankObj);

				// Updating In Transaction Table
				transObj.setTransactionType("Withdraw");
				transObj.setAccId(withId);
				transObj.setAmount(withdrawAmt);
				serviceObj.addTransaction(transObj);
				bankObj.setTransaction(transObj);

				bankObj = serviceObj.getAccountById(withId);
				System.out.println("Hello!! Welcome " + bankObj.getAccountantName());
				System.out.println(
						"Your Remaining Account Balance after Withdrawing Rs " + withdrawAmt + " is " + bankObj.getAccBalance());
				System.out.println("\n-------------------------------------------------------------\n");
				break;
			case 5:
				System.out.println("----------Fund Transfer----------");
				System.out.println("Enter the From Account Id:");
				int fromId = scan.nextInt(); // From Account Id (Sender)
				if (fromId == 0) {
					throw new InvalidException("Enter valid Account Id");
				}
				bankObj = serviceObj.getAccountById(fromId);
				int balance = bankObj.getAccBalance(); // Initial Balance
				System.out.println("Enter the amount you want to transfer:");
				int fundAmt = scan.nextInt(); // Amount to be transfered
				System.out.println("Enter Receiver Account Id:");
				int transId = scan.nextInt();
				if (transId == 0) {
					throw new InvalidException("Enter valid Account Id.");
				}

				// Removing the Balance transfered from sender Account
				bankObj = serviceObj.getAccountById(fromId);
				int bal1 = balance - fundAmt;
				bankObj.setAccBalance(bal1);
				serviceObj.Deposit(bankObj);

				// Updating the Balance received from Sender
				bankObj = serviceObj.getAccountById(transId);
				int tbal = bankObj.getAccBalance();
				int tbalance = tbal + fundAmt;
				bankObj.setAccBalance(tbalance);
				serviceObj.Deposit(bankObj);

				// updating In transaction Table
				transObj.setTransactionType("Transfered to " + transId);
				transObj.setAccId(fromId);
				transObj.setAmount(fundAmt);
				serviceObj.addTransaction(transObj);
				bankObj.setTransaction(transObj);
				int flag = transObj.getTransactionId();

				bankObj = serviceObj.getAccountById(fromId);
				System.out.println("Hello!! Welcome " + bankObj.getAccountantName());
				System.out.println("Remaining balance in account : " + bankObj.getAccBalance());
				System.out.println("\n-------------------------------------------------------------\n");
				break;

			case 6:
				System.out.println("----------Print Transaction Details----------");
				System.out.println("Enter the account id:");
				int transid = scan.nextInt();
				serviceObj.PrintTransactions(transid);
				System.out.println("\n\n-------------------------------------------------------------");
				break;
			case 7:
				System.out.println("     Thank You!!");
				System.exit(0);
			}
		} while (true);
	}
}