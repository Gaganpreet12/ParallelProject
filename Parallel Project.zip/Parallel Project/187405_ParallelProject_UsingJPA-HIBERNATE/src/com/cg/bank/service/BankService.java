package com.cg.bank.service;

import com.cg.bank.dao.BankDAO;
import com.cg.bank.entity.BankDetails;
import com.cg.bank.entity.TransactionDetails;

public class BankService implements BankServiceInterface {
	BankDAO daoObj = new BankDAO();

	@Override
	public BankDetails getAccountById(int accId) {
		BankDetails bankObj = daoObj.getAccountById(accId);
		return bankObj;
	}

	@Override
	public void CreateAccount(BankDetails bankObj) {
		daoObj.beginTransaction();
		daoObj.CreateAccount(bankObj);
		daoObj.commitTransaction();
	}

	@Override
	public void ShowBalance(BankDetails bankObj) {
		
	}

	@Override
	public void Deposit(BankDetails bankObj) {
		daoObj.beginTransaction();
		daoObj.Deposit(bankObj);
		daoObj.commitTransaction();

	}

	@Override
	public void Withdraw(BankDetails bankObj) {
		daoObj.beginTransaction();
		daoObj.Withdraw(bankObj);
		daoObj.commitTransaction();
	}

	@Override
	public void PrintTransactions(int accId) {
		daoObj.PrintTransactions(accId);

	}

	@Override
	public void commitTransaction() {
		daoObj.commitTransaction();

	}

	@Override
	public void beginTransaction() {
		daoObj.beginTransaction();
	}

	public void addTransaction(TransactionDetails transObj) {

		daoObj.beginTransaction();
		daoObj.addTransaction(transObj);
		daoObj.commitTransaction();
	}

}
