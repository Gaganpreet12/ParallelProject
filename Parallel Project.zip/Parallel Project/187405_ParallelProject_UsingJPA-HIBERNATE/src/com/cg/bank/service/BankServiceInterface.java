package com.cg.bank.service;

import com.cg.bank.entity.BankDetails;

public interface BankServiceInterface {
	public   BankDetails getAccountById(int id);

	public   void CreateAccount(BankDetails bankObj);

	public   void ShowBalance(BankDetails bankObj);

	public  void Deposit(BankDetails bankObj);
	
	public void Withdraw(BankDetails bankObj);
	
	public void PrintTransactions(int accId);

	public  void commitTransaction();

	public void beginTransaction();

}
