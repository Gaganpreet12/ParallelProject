package com.cg.bank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.bank.entity.BankDetails;
import com.cg.bank.entity.TransactionDetails;

public class BankDAO implements BankDAOInterface {

	EntityManager entityManager = UtilJava.getEntityManager();

	@Override
	public BankDetails getAccountById(int accId) {
		BankDetails bankObj = entityManager.find(BankDetails.class, accId);
		return bankObj;
	}

	@Override
	public void CreateAccount(BankDetails bankObj) {
		entityManager.persist(bankObj);

	}

	@Override
	public void ShowBalance(BankDetails bankObj) {
	}

	@Override
	public void Deposit(BankDetails bankObj) {
		entityManager.merge(bankObj);

	}

	@Override
	public void Withdraw(BankDetails bankObj) {
		entityManager.merge(bankObj);

	}

	public void PrintTransactions(int accId) {
		Query query = entityManager.createQuery("select t from TransactionDetails t where accId=:tid");
		query.setParameter("tid", accId);
		List<TransactionDetails> lists = query.getResultList();
		System.out.println("TransactionId		Account Id		TrasactionType		Amount");
		System.out.println("------------------------------------------------------------------");
		for (TransactionDetails transdetails : lists) {
			System.out.println(transdetails.getTransactionId() + "			" + transdetails.getAccId() + "			"
					+ transdetails.getTransactionType() + "		" + transdetails.getAmount());
		}
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

	public void addTransaction(TransactionDetails transObj) {

		entityManager.persist(transObj);
	}

}
