package com.cg.collection.dao;

import com.cg.collection.bean.BankBean;

public interface BankDaoInterface {

	public BankBean checkAccount(long accNo);

	public void setData(long accNum, BankBean beanObj);

}
